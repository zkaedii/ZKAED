import os
import random
import math
import statistics
from h_hat_predictor import HHatPredictor

def generate_random_params():
    return {
        "A": random.uniform(0.5, 1.5),
        "B": random.uniform(0.5, 2.0),
        "phi": random.uniform(0, 3.14),
        "C": random.uniform(0.1, 0.9),
        "D": random.uniform(0.01, 0.05),
        "alpha0": random.uniform(0.001, 0.01),
        "alpha1": random.uniform(0.1, 0.5),
        "alpha2": random.uniform(0.1, 0.5),
        "eta": random.uniform(0.01, 0.1),
        "sigma": random.uniform(0.1, 0.3),
        "beta": random.uniform(0.05, 0.3),
        "delta": random.uniform(0.01, 0.1),
        "tau": random.uniform(1.0, 3.0),
        "t": round(random.uniform(0.1, 100), 3)
    }

def run_deep_dive(num_cases=50):
    predictor = HHatPredictor()
    predictions = []
    parameter_log = []

    print(f"📊 Running {num_cases} extended test cases...")
    for i in range(num_cases):
        params = generate_random_params()
        prediction = predictor.predict_from_params(params)
        predictions.append(prediction)
        parameter_log.append((params, prediction))

        if i < 10:
            print(f"Test {i+1}:")
            print("Params:", params)
            print("Predicted Ĥ(t):", round(prediction, 6))
            print("-" * 50)

    print("\n📈 Summary Metrics")
    print("Mean Ĥ(t):", round(statistics.mean(predictions), 6))
    print("Min Ĥ(t):", round(min(predictions), 6))
    print("Max Ĥ(t):", round(max(predictions), 6))
    print("Standard Deviation:", round(statistics.stdev(predictions), 6))

    # Identify extremes
    sorted_log = sorted(parameter_log, key=lambda x: x[1])
    print("\n🔍 Lowest Prediction Sample:")
    print("Ĥ(t):", round(sorted_log[0][1], 6))
    print("Params:", sorted_log[0][0])

    print("\n🔍 Highest Prediction Sample:")
    print("Ĥ(t):", round(sorted_log[-1][1], 6))
    print("Params:", sorted_log[-1][0])

if __name__ == "__main__":
    run_deep_dive()