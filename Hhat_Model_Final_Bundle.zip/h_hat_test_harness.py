import os
import random
import math
from h_hat_predictor import HHatPredictor

def generate_random_params():
    return {
        "A": random.uniform(0.5, 1.5),
        "B": random.uniform(0.5, 2.0),
        "phi": random.uniform(0, 3.14),
        "C": random.uniform(0.1, 0.9),
        "D": random.uniform(0.01, 0.05),
        "alpha0": random.uniform(0.001, 0.01),
        "alpha1": random.uniform(0.1, 0.5),
        "alpha2": random.uniform(0.1, 0.5),
        "eta": random.uniform(0.01, 0.1),
        "sigma": random.uniform(0.1, 0.3),
        "beta": random.uniform(0.05, 0.3),
        "delta": random.uniform(0.01, 0.1),
        "tau": random.uniform(1.0, 3.0),
        "t": round(random.uniform(0.1, 100), 3)
    }

def run_test_cases(num_cases=10):
    predictor = HHatPredictor()
    print(f"Running {num_cases} test cases...")
    for i in range(num_cases):
        params = generate_random_params()
        prediction = predictor.predict_from_params(params)
        print(f"Test {i+1}:")
        print("Input Parameters:", params)
        print("Predicted Output Ĥ(t):", round(prediction, 6))
        print("-" * 60)

if __name__ == "__main__":
    run_test_cases()