import joblib
import os

class HHatPredictor:
    def __init__(self, model_path="h_hat_predictor_model_baked.pkl"):
        self.model_path = model_path
        self.model_bundle = self.load_model()
        self.model = self.model_bundle["model"]
        self.metadata = self.model_bundle["metadata"]

    def load_model(self):
        return joblib.load(os.path.join(os.path.dirname(__file__), self.model_path))

    def predict_from_params(self, param_dict):
        ordered_keys = ["A", "B", "phi", "C", "D", "alpha0", "alpha1", "alpha2", "eta", "sigma", "beta", "delta", "tau", "t"]
        x = [[param_dict[k] for k in ordered_keys]]
        return self.model.predict(x)[0]

    def get_feature_importances(self):
        return dict(zip(self.model.feature_names_in_, self.model.feature_importances_))

    def get_metadata(self):
        return self.metadata